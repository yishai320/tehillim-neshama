# אותיות נשמה — Android APK project

A ready-to-build Android app that wraps the Tehillim reader in a WebView.
All content (HTML/CSS/JS + icons) is bundled in `app/src/main/assets/`, so the
app runs fully offline. Only the decorative Google Fonts load from the network
when online; offline it falls back to the system Hebrew font.

## Option A — Build the APK in Android Studio (recommended)
1. Install Android Studio (free). It brings its own JDK + Android SDK + Gradle.
2. File > Open… and select this folder. Let it finish "Gradle Sync"
   (first sync downloads the SDK/Gradle bits automatically — needs internet once).
3. Build > Build Bundle(s)/APK(s) > Build APK(s).
4. When it finishes, click "locate" — the file is:
   app/build/outputs/apk/debug/app-debug.apk
5. Copy that .apk to an Android phone and open it (allow "install from unknown
   sources"). That debug APK is fine for personal/family use.

For a Play-Store-ready signed build: Build > Generate Signed Bundle/APK, and
follow the wizard to create a keystore.

## Option B — No tools at all (fastest): PWABuilder
Because the web app is already a proper PWA (manifest + service worker + icons):
1. Host the web folder over https (e.g. Netlify Drop or GitHub Pages).
2. Go to https://www.pwabuilder.com , paste the URL, and choose "Package for
   Android". It generates a signed APK/AAB you can download and install.

## App details
- Package / applicationId: com.neshama.tehillim
- Min Android: 7.0 (API 24)   Target: Android 14 (API 34)
- Launcher name: אותיות נשמה
- Icon: memorial candle (נר נשמה)

## Change the app name or icon
- Name: app/src/main/res/values/strings.xml
- Icon: replace the ic_launcher.png files under app/src/main/res/mipmap-*/
- App content: edit app/src/main/assets/index.html
